'use strict'
module.exports = {
    devServer: {
      port: 7001  // 此处修改你想要的端口号，
    }
  }
