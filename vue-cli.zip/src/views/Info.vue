<template>
  <el-row>
        <el-col :span=16>
            <div style="margin-left:50%">
                <div>用户名：</div>
            </div>
        </el-col>
    </el-row>
</template>

<script>
export default {
    name: 'Info',
    data(){
        return{
            user:{
                
            }
        }
    }
}
</script>

<style>

</style>